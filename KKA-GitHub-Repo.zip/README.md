# Misi Piksel: Koding dan Kecerdasan Artifisial

Game edukasi 5 level untuk materi KKA (Koding dan Kecerdasan Artifisial).

Level: Algoritma, Perulangan, Percabangan, Debugging Tim, Kecerdasan Artifisial.

Mainkan: https://USERNAME.github.io/NAMA-REPO/

Dibuat dengan bantuan AI (Claude). Aset: emoji, CSS, dan Web Audio (tanpa file eksternal).
